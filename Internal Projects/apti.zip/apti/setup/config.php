<?php
/**
 * Config variables
 */
define('NAME', "http://localhost/apti/");
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "aptitude");
define("THEME_URL", NAME."assets/theme/");
define("CSS_URL", NAME."assets/css/");
define("JS_URL", NAME."assets/js/");
define("PHP_URL", NAME."assets/php/");
?>