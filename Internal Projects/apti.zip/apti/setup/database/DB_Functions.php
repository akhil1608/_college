<?php
class DB_Functions {
    private $conn;
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }
    // destructor
    function __destruct() {}

    public function storeUser($name, $email, $password, $branch, $type) {
         $uuid = uniqid('', true);
         $password = md5($password);
         $stmt = $this->conn->prepare("INSERT INTO users( id, name, email, password, branch, type) VALUES( NULL, ?, ?, ?, ?, ?)");
       
         $stmt->bind_param("sssss", $name, $email ,$password, $branch, $type);
		 $result = $stmt->execute();
         $stmt->close();
        return $result;
     }
		
    public function getUserByEmailAndPassword($email, $password) {
        $stmt = $this->conn->prepare("SELECT id, name, branch, type FROM users WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $email,$password);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                $result = $row;
            return $result;
        }
        else 
            return false;
    }

    public function getEmailByID($id) {
        $stmt = $this->conn->prepare("SELECT name, email FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                $result = $row;
            return $result;
        }
        else 
            return false;
    }

     public function doesEmailExist($email) {
         $stmt = $this->conn->prepare("SELECT * from users WHERE email = ?");
         $stmt->bind_param("s", $email);
         $stmt->execute();
         $stmt->store_result();
         if ($stmt->num_rows > 0) {
            //email exists
            $stmt->close();
            return true;
         } 
         else {
            // email does not exist
            $stmt->close();
            return false;
        }
    }

    public function questionData($category,$limit) {
        $stmt = $this->conn->prepare("SELECT * FROM questions WHERE category = ? ORDER BY rand() LIMIT ?");
        $stmt->bind_param("si", $category,$limit);
        if ($stmt->execute()) {
            $result = array();
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                array_push($result,$row);
            return $result;
        }
    }

    public function solution($qlist) {
        $stmt = $this->conn->prepare("SELECT id,answer FROM questions WHERE id IN ".$qlist);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                $result[$row['id']]=$row['answer'];
            return $result;
        }
    }

    public function addQuestion($question) { 
        $stmt = $this->conn->prepare("INSERT INTO questions VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $question["question"],$question["opt_A"],$question["opt_B"],$question["opt_C"],$question["opt_D"],$question["correct_opt"],$question["category"]);
        $res = $stmt->execute();
        return $res;
    }

    public function submitTest($data) { 
        $stmt = $this->conn->prepare("INSERT INTO statistics VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)");
        $stmt->bind_param("isiiiiiiiiiiiii", $data["test_id"],$data["test_name"],$data["student_id"],$data["total_questions"],$data["max_score"],$data["total_score"],$data["verbal_score"],$data["quant_score"],$data["technical_score"],$data["verbal_correct"],$data["verbal_incorrect"],$data["quant_correct"],$data["quant_incorrect"],$data["technical_correct"],$data["technical_incorrect"]);
        $res = $stmt->execute();
        return $res;
    }

    public function failedTest($i,$d,$t,$s) {
        $stmt = $this->conn->prepare("INSERT INTO failed VALUES (NULL, ?, ?, ?, ?)");
        $stmt->bind_param("sisi",$i,$d,$t,$s);
        $res = $stmt->execute();
        return $res;
    }

    public function alreadyFailed($d,$t) {
        $stmt = $this->conn->prepare("DELETE from failed WHERE student_id = ? AND test_name = ?");
        $stmt->bind_param("is",$d,$t);
        $res = $stmt->execute();
        return $res;
    }

    public function getPendingStudents() {
        $stmt = $this->conn->prepare("SELECT u.name as student_name, t.name as test_name, t.end_date as end_date FROM users as u,tests as t WHERE u.type='student' AND now() >= t.end_date-7 AND t.id NOT IN (SELECT test_id from statistics WHERE student_id = u.id)");
        if ($stmt->execute()) {
            $result = array();
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc()) {
                array_push($result,$row);
            }
            return $result;
        }
    }

    public function getFailedStudentList() {
        $stmt = $this->conn->prepare("SELECT * FROM failed");
        if ($stmt->execute()) {
            $result = array();
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc()) {
                array_push($result,$row);
            }
            return $result;
        }
    }

    public function createTest($test) { 
        print_r($test);

        $stmt = $this->conn->prepare("INSERT INTO tests VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("siiiisss", $test["name"],$test["dur"],$test["quant"],$test["verbal"],$test["tech"],$test["start_date"],$test["end_date"],$test["branch"]);
        $res = $stmt->execute();
        // exit;   
        return $res;
    }

    public function baseStats($stud_id) {
        $stmt = $this->conn->prepare("SELECT COUNT(student_id) as N, SUM(verbal_correct+quant_correct+tech_correct+verbal_incorrect+quant_incorrect+tech_incorrect) as AT, SUM(total_score) as TS, SUM(max_score) as MS, SUM(verbal_correct+quant_correct+tech_correct) as C FROM `statistics` WHERE student_id = ?");
        $stmt->bind_param("i", $stud_id);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                $result = $row;
            return $result;
        }
        else 
            return false;
    }

    public function getStats($stud_id) {
        $stmt = $this->conn->prepare("SELECT * FROM statistics where student_id = ?");
        $stmt->bind_param("i", $stud_id);
        if ($stmt->execute()) {
            $result = array();
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc()) {
                array_push($result,$row);
            }
            return $result;
        }
    }

    public function getTest($test_id) {
        $stmt = $this->conn->prepare(" SELECT * FROM tests WHERE id = ?");
        $stmt->bind_param("i",$test_id);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                $result=$row;
            return $result;
        }
    }

    public function pendingTests($stud_id,$branch) {
        $stmt = $this->conn->prepare("SELECT * FROM tests WHERE branch = ? AND now() > tests.start_date AND tests.id NOT IN (SELECT test_id from statistics WHERE student_id = ?)");
        $stmt->bind_param("si",$branch,$stud_id);
        if ($stmt->execute()) {
            $result = array();
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc())
                array_push($result,$row);
            return $result;
        }
    } 
}
 
?>