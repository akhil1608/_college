<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="teacher")
    	header("Location: ../teacher/home.php")
?>
<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$cp = new Components();
	$db = new DB_Functions();
	$tests = $db->pendingTests($_SESSION["id"],$_SESSION["branch"]);
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Pending Tests</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

    <?php $cp->sidebar(THEME_URL,1); ?>

	<div class="main-panel">

		<?php $cp->header(NAME,$_SESSION["name"]); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <?php if(empty($tests)){?><div class="content"><h3>No pending tests</h3></div><?php } else {?>
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                        <th>Test Name</th>
                                        <th>Total Questions</th>
                                        <th>Duration</th>
                                    </thead>
                                    <tbody>
                                        <?php $c = 0; foreach($tests as $t) {?>
                                            <tr>
                                                <td><?php echo ++$c; ?></td>
                                                <td><?php echo $t['name']; ?></td>
                                                <td><?php echo ($t['quant']+$t['verbal']+$t['technical']); ?></td>
                                                <td><?php echo $t['duration']; ?></td>
                                                <td>
                                                    <form action="instructions.php" method="post">
                                                        <input type="hidden" name="test_id" value="<?php echo $t['id']; ?>">
                                                        <input type="submit" value="Give the Test">
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php }}?>
                        	        </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $cp->footer(THEME_URL); ?>

    </div>
</div>
</body>
        <?php $cp->js(THEME_URL); ?>
</html>