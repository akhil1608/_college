<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="teacher")
    	header("Location: ../teacher/home.php")
?>
<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$cp = new Components();
	$db = new DB_Functions();
	$stats = $db->getStats($_SESSION["id"]);

?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Statistics</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

    <?php $cp->sidebar(THEME_URL,2); ?>

	<div class="main-panel">

		<?php $cp->header(NAME,$_SESSION["name"]); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <?php if(empty($stats)){?><div class="content"><h3>No test given yet</h3></div><?php } else {?>
                            	<table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                        <th>Test Name</th>
                                        <th>Score</th>
                                        <th>Date</th>
                                    </thead>
                                    <tbody>
                                        <?php $c = 0; foreach($stats as $s) {?>
                                        <tr class="drop" data-toggle="collapse" data-target="#row<?php echo ++$c;?>">
                                            <td><?php echo $c; ?></td>
                                            <td><?php echo $s['test_name']; ?></td>
                                            <td><?php echo $s['total_score']; ?></td>
                                            <td><?php echo $s['timestamp']; ?></td>
                                        </tr>
                                        <tr class="collapse in hrow" id="row<?php echo $c;?>">
                                            <td>
                                                <div id="chartA<?php echo $c;?>" class="ct-chart ct-perfect-fourth"></div>
                                            </td>
                                            <td>
                                                Max Score: <?php echo $s['max_score']; ?><br>
                                                Verbal Score: <?php echo $s['verbal_score']; ?><br>
                                                Quant Score: <?php echo $s['quant_score']; ?><br>
                                                Tech Score: <?php echo $s['tech_score']; ?>
                                            </td>
                                            <td>
                                                <div id="chartB<?php echo $c;?>" class="ct-chart ct-perfect-fourth"></div>
                                            </td>
                                            <td>
                                                Total Questions: <?php echo $s['total_questions']; ?><br>
                                                Attempted: <?php echo ($s['verbal_correct']+$s['quant_correct']+$s['tech_correct']+$s['verbal_incorrect']+$s['quant_incorrect']+$s['tech_incorrect']); ?><br>
                                                Correct: <?php echo ($s['verbal_correct']+$s['quant_correct']+$s['tech_correct']); ?><br>
                                                Incorrect: <?php echo ($s['verbal_incorrect']+$s['quant_incorrect']+$s['tech_incorrect']); ?>

                                            </td>
                                        </tr>
                                        <?php }}?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $cp->footer(THEME_URL); ?>

    </div>
</div>
</body>
<?php $cp->js(THEME_URL); ?>
<script type="text/javascript">
    <?php 
        $c = 0;
        foreach ($stats as $s) {
            echo "pie('chartA".++$c."',[".$s['verbal_score'].",".$s['quant_score'].",".$s['tech_score']."],1);";
            echo "pie('chartB".$c."',[".($s['verbal_correct']+$s['quant_correct']+$s['tech_correct']).",".($s['verbal_incorrect']+$s['quant_incorrect']+$s['tech_incorrect'])."],0);";
        }
    ?>
    function pie(id,s,l) {
        var t = 0;
        for (var i=0;i<s.length;i++) 
            t+=s[i];
        if(l)
            l = ["Verbal","Quant","Tech"];
        else {
            s = [s[0]];
            l = ["Correct","Incorrect"];
        }

        Chartist.Pie('#'+id, 
            {
                labels: l,
                series: s
            },
            {
                donut: false,
                startAngle: 0,
                total: t,
                showLabel: true
            }
        );
    }
    $(document).ready( function() { $(".hrow").removeClass("in"); });
</script>
</html>