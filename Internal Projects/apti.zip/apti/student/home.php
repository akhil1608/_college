<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="teacher")
    	header("Location: ../teacher/home.php");
?>
<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$cp = new Components();
	$db = new DB_Functions();
	$basestats = $db->baseStats($_SESSION["id"]);
	$n = $basestats["N"];
	$r = ($n == 0) ? 0 : (($basestats["MS"] == 0) ? 0 : round($basestats["TS"]*10/$basestats["MS"],1));
	$a = ($n == 0) ? 0 : (($basestats["AT"] == 0) ? 0 : round($basestats["C"]*100/$basestats["AT"]));
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Home</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

    <?php $cp->sidebar(THEME_URL,0); ?>

	<div class="main-panel">

		<?php $cp->header(NAME,$_SESSION["name"]); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                        	<div class="header text-center">
                                <h4 class="title">Tests Given</h4>
                            </div>
                            <div class="content">
                            	<div id="total" class="ct-chart ct-perfect-fourth">
                            		<div class="hvcenter"><h1 class="title"><?php echo $n; ?></h1></div>
                            	</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                        	<div class="header text-center">
                                <h4 class="title">Accuracy</h4>
                            </div>
                            <div class="content">
                            	<div id="accuracy" class="ct-chart ct-perfect-fourth">
                            		<div class="hvcenter"><h1 class="title"><?php echo $a; ?>%</h1></div>
                            	</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                        	<div class="header text-center">
                                <h4 class="title">Average Score</h4>
                            </div>
                            <div class="content">
                                <div id="average" class="ct-chart ct-perfect-fourth">
                                	<div class="hvcenter"><h1 class="title"><?php echo $r; ?></h1></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $cp->footer(THEME_URL); ?>

    </div>
</div>
</body>
<?php $cp->js(THEME_URL); ?>
<script type="text/javascript">
	<?php $n = ($n == 0) ? 1 : $n; ?>
	pie(<?php echo '"total",'.$n.','.$n.',false' ; ?>);
	pie(<?php echo '"accuracy",'.$a.',100,false' ; ?>);
	pie(<?php echo '"average",'.($r*10).',100,true' ; ?>);
	function pie(id,s,t,d) {
		console.log(d);
		Chartist.Pie('#'+id, 
			{
				series: [s]
			},
			{
				donut: d,
				startAngle: 0,
				total: t,
				showLabel: false
			}
		);
	}
</script>
</html>