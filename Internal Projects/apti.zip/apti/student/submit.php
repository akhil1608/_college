<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="teacher")
    	header("Location: ../teacher/home.php");
?>
<?php 
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	$db = new DB_Functions();
	$basestats = $db->baseStats($_SESSION["id"]);
	$n = $basestats["N"];
	$r = ($n == 0) ? 0 : (($basestats["MS"] == 0) ? 0 : round($basestats["TS"]*10/$basestats["MS"],1));
	$solution = $db->solution($_POST['qlist']);
	$data['test_id'] = $_POST['test_id'];
	$data['test_name'] = $_POST['test_name'];
	$data['student_id'] = $_SESSION['id'];
	$data['total_questions'] = $_POST['qt']+$_POST['vt']+$_POST['tt'];
	$data['max_score'] = $data['total_questions']*3;
	$data['quant_correct'] = $data['quant_incorrect'] = $data['verbal_correct'] = $data['verbal_incorrect'] = $data['technical_correct'] = $data['technical_incorrect'] = 0;
	foreach ($_POST as $key => $value) {
		if($key[0]=='Q') {
			$k = substr($key, 1);
			if($value=="dna")
				continue;
			else {
				if($solution[$k]==$value)
					$data['quant_correct']++;
				else
					$data['quant_incorrect']++;
			}
		}
		if($key[0]=='V') {
			$k = substr($key, 1);
			if($value=="dna")
				continue;
			else {
				if($solution[$k]==$value)
					$data['verbal_correct']++;
				else
					$data['verbal_incorrect']++;
			}
		}
		if($key[0]=='T') {
			$k = substr($key, 1);
			if($value=="dna")
				continue;
			else {
				if($solution[$k]==$value)
					$data['technical_correct']++;
				else
					$data['technical_incorrect']++;
			}
		}
	}
	$data['quant_score'] = $data['quant_correct']*3;
	$data['verbal_score'] = $data['verbal_correct']*3;
	$data['technical_score'] = $data['technical_correct']*3;
	$data['total_score'] = $data['quant_score']+$data['verbal_score']+$data['technical_score'];
	$cutoff = 20+$r*5;
	if($cutoff<40)
		$cutoff = 40;
	if($data['total_score']<$cutoff/$data['max_score']) 
		$db->failedTest($_SESSION['name'],$_SESSION["id"],$data['test_name'],$data['total_score']);
	else {
		$db->alreadyFailed($_SESSION["id"],$data['test_name']);
		$db->submitTest($data);
	}
	header("Location: home.php");
?>