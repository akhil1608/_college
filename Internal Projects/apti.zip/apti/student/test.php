<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="teacher")
    	header("Location: ../teacher/home.php");
?>
<?php 
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$db = new DB_Functions();
	$cp = new Components();
	$test = $db->getTest($_POST["test_id"]);
	$quant = $db->questionData('quant',$test['quant']);
	$verbal = $db->questionData('verbal',$test['verbal']);
	$technical = $db->questionData($_SESSION['branch'],$test['technical']);
	$qlist = "(";
	foreach ($quant as $q)
		$qlist .= $q['id'].",";
	foreach ($verbal as $v)
		$qlist .= $v['id'].",";
	foreach ($technical as $te)
		$qlist .= $te['id'].",";
	$qlist = rtrim($qlist,",").")";
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Tests</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

		<?php $cp->header(NAME,$test["name"]); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                	<div class="col-md-3">
                		<div class="card">
                			<div class="content">
                				<h4 class="title">Jump to Question</h4>
                				<h5>Quantitative</h5>
                				<?php for($i=1;$i<=count($quant);$i++) { ?>
						 			<button id="b<?php echo $i;?>" class="navigation" onclick="navi(<?php echo $i; ?>)"><?php echo $i; ?></button>
						 		<?php } ?>
						 		<h5>Verbal</h5>
                				<?php for($j=1;$j<=count($verbal);$j++) { ?>
						 			<button id="b<?php echo $i+$j-1;?>" class="navigation" onclick="navi(<?php echo $i+$j-1; ?>)"><?php echo $i+$j-1; ?></button>
						 		<?php } ?>
						 		<h5>Technical</h5>
                				<?php for($k=1;$k<=count($technical);$k++) { ?>
						 			<button id="b<?php echo $i+$j+$k-2; ?>" class="navigation" onclick="navi(<?php echo $i+$j+$k-2; ?>)"><?php echo $i+$j+$k-2; ?></button>
						 		<?php } ?>
                			</div>
                		</div>
                	</div>
                    <div class="col-md-6">
                        <div class="card">
							<div class="questions">
								<form action="submit.php" method="post" id="test-form">
									<input type="hidden" name="qt" value="<?php echo $test['quant']; ?>">
									<input type="hidden" name="vt" value="<?php echo $test['verbal']; ?>">
									<input type="hidden" name="tt" value="<?php echo $test['technical']; ?>">
									<input type="hidden" name="qlist" value="<?php echo $qlist; ?>">
									<input type="hidden" name="test_id" value="<?php echo $test['id']; ?>">
									<input type="hidden" name="test_name" value="<?php echo $test['name']; ?>">
									<?php 
									$c = 0;
									if(!empty($quant)) {
									foreach($quant as $t) {?>
										<div class="question hidden" id="q<?php echo ++$c; ?>" >
											Quantitative:<br>
											Question <?php echo $c; ?>: <br>
											<?php echo $t['question']; ?><br>
											<input type="radio" name="Q<?php echo $t['id']; ?>" value="dna" class="hidden" checked>
											<input type="radio" name="Q<?php echo $t['id']; ?>" value="A"><?php echo $t['opt_A']; ?>
											<input type="radio" name="Q<?php echo $t['id']; ?>" value="B"><?php echo $t['opt_B']; ?><br>
											<input type="radio" name="Q<?php echo $t['id']; ?>" value="C"><?php echo $t['opt_C']; ?>
											<input type="radio" name="Q<?php echo $t['id']; ?>" value="D"><?php echo $t['opt_D']; ?>
										</div>
									<?php }} 
									if(!empty($verbal)) {
									foreach($verbal as $t) {?>
										<div class="question hidden" id="q<?php echo ++$c; ?>" >
											Verbal:<br>
											Question <?php echo $c; ?>: <br>
											<?php echo $t['question']; ?><br>
											<input type="radio" name="V<?php echo $t['id']; ?>" value="dna" class="hidden" checked>
											<input type="radio" name="V<?php echo $t['id']; ?>" value="A"><?php echo $t['opt_A']; ?>
											<input type="radio" name="V<?php echo $t['id']; ?>" value="B"><?php echo $t['opt_B']; ?><br>
											<input type="radio" name="V<?php echo $t['id']; ?>" value="C"><?php echo $t['opt_C']; ?>
											<input type="radio" name="V<?php echo $t['id']; ?>" value="D"><?php echo $t['opt_D']; ?>
										</div>
									<?php }} 
									if(!empty($technical)) {
									foreach($technical as $t) {?>
										<div class="question hidden" id="q<?php echo ++$c; ?>" >
											Technical:<br>
											Question <?php echo $c; ?>: <br>
											<?php echo $t['question']; ?><br>
											<input type="radio" name="T<?php echo $t['id']; ?>" value="dna" class="hidden" checked>
											<input type="radio" name="T<?php echo $t['id']; ?>" value="A"><?php echo $t['opt_A']; ?>
											<input type="radio" name="T<?php echo $t['id']; ?>" value="B"><?php echo $t['opt_B']; ?><br>
											<input type="radio" name="T<?php echo $t['id']; ?>" value="C"><?php echo $t['opt_C']; ?>
											<input type="radio" name="T<?php echo $t['id']; ?>" value="D"><?php echo $t['opt_D']; ?>
										</div>
									<?php }} ?>
								</form>
								<input class="hidden" type="button" id="pre" onclick="previous()" value="Previous">
								<input type="button" id="next" onclick="next()" value="Next" >
								<input type="button" id="review" value="Mark for review" >
								<input type="button" id="unselect" value="Unselect the option" >
							</div>
						</div>
					</div>
					<div class="col-md-3">
                		<div class="card">
                			<div class="content">
                					<input type="hidden" id="counter" value="<?php echo $test['duration']; ?>">
                					Time Left: <span class="timer" id="timer"></span>
                					<div><button onclick="post()">Submit Test</button></div>
                			</div>
                		</div>
                	</div>
				</div>
			</div>
		</div>
		
		<?php $cp->footer(THEME_URL); ?>


</div>
</body>
		<?php $cp->js(THEME_URL); ?>			
		<script type="text/javascript" src='<?php echo JS_URL."questions.js"; ?>'></script>
		<script type="text/javascript" src='<?php echo JS_URL."timer.js"; ?>'></script>
		<script type="text/javascript" src='<?php echo JS_URL."color.js"; ?>'></script>
		<script type="text/javascript" src='<?php echo JS_URL."cheat.js"; ?>'></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$(".question").first().removeClass("hidden");
				$(".navigation").first().addClass("current");
			});
		</script>

</html>