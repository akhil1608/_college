<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="teacher")
    	header("Location: ../teacher/home.php");
?>
<?php 
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$db = new DB_Functions();
	$cp = new Components();
	$test = $db->getTest($_POST["test_id"]);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Instructions</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

		<?php $cp->header(NAME,$test["name"]); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                	<div class="col-md-2"></div>
                    <div class="col-md-8">
                        <div class="card">
                        	<div class="content"><h2 class="title">Instructions</h2></div>
                        	<div class="content">
                        		<h4 class="title">Basic</h4>
                    			<ul>
                    				<li>Before attempting the test, make sure you have proper connectivity to the internet with good speed.</li>
                    				<li>The test window will open on a new tab/window.</li>
                    				<li>Once you begin the test, do not switch tabs or windows. Stay on the same page or else the test will be automatically submitted.</li>
                    				<li>Do not refresh the page, or else the test will be automatically submitted.</li>
                    			</ul>
                        		<h4 class="title">Test</h4>
                    			<ul>
                    				<li>You have <?php echo $test['duration'];?> minutes to attempt all the questions</li>
                        			<li>The test has 3 sections; Quantitative, Verbal and Technical.</li>
                        			<li>Quantitative section has <?php echo $test['quant'];?> questions</li>
                        			<li>Verbal section has <?php echo $test['verbal'];?> questions</li>
                        			<li>Technical section has <?php echo $test['technical'];?> questions</li>
                        			<li>Each question carries 3 marks for right answer, and no negative marking for wrong ones.</li>
                        			<li>Total number of questions in the test: <?php echo ($test['quant']+$test['verbal']+$test['technical']);?></li>
                        			<li>Maximum score: <?php echo 3*($test['quant']+$test['verbal']+$test['technical']);?></li>
                    			</ul>
                    			<form action="test.php" target="_blank" method="post">
                    				<input type="hidden" name="test_id" value="<?php echo $test['id']; ?>">
                    				<input type="submit" id="start" value="Start Test">
                    			</form>                        		
                        	</div>
						</div>
					</div>
					<div class="col-md-2"></div>
				</div>
			</div>
		</div>
		
		<?php $cp->footer(THEME_URL); ?>


</div>
</body>
		<?php $cp->js(THEME_URL); ?>
		<script type="text/javascript">
			$(document).ready(function() {
				var clicked = 0;
				$("#start").click(function() {
                    alert("sdfsf");
					clicked=1;
				});
				setInterval(function() {
					if(clicked==1)
						window.location.replace("home.php");
				},1000);
			});
		</script>			
</html>