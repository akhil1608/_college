<?php
require_once 'setup/database/DB_Functions.php';
$db = new DB_Functions();
if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['branch']) && isset($_POST['type'])) {
 
    // receiving the post params
    $name = $_POST['name'];
    $email = $_POST['email'];
	$password = $_POST['password'];
    $branch = $_POST['branch'];
	$type = $_POST['type'];

    // check if user is already existed with the same email
    if ($db->doesEmailExist($email)) {
        // user already existed
        echo "<script>alert('Email already exists');</script>";
    }
	else {
        // create a new user
        $sinup1 = $db->storeUser($name, $email, $password, $branch, $type);
		if ($sinup1) {
            echo "<script>alert('User stored successfully');</script>";
        }
		else {
            // user failed to store
            echo "<script>alert('Unknown error occurred in registration!');</script>";
        }
    }
}
?>

<html>
    <head>
        <meta charset="utf-8" />
        <!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>Register</title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />
        <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>bootstrap/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    </head>
    <body>
        <div class="container hvcenter">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <div class="form-container text-center">
                        <form method="post">   
                            <div class="form-group">
			                    <input class="form-control" type="text" placeholder="Name" required id="name" name="name"/>
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="email" placeholder="Email" required id="email" name="email"/>
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="password" placeholder="Password" required id="password" name="password"/>
                            </div>
                            <div class="form-group">
                                <label>Branch:</label>
                                <select class="form-control" name="branch">
                                    <option value="techCSIT" selected>Comps</option>
                                    <option value="techCSIT">IT</option>
                                    <option value="techME">Mech</option>
                                    <option value="techEL">Elec</option>
                                    <option value="techEX">EXTC</option>
                                </select>
                            </div>			
            	            <div class="form-group">
                                <label>Account Type:</label>
                                <select class="form-control" name="type">
                                    <option value="student" selected>Student</option>
                                    <option value="teacher">Teacher</option>
                                </select>
                            </div>
                            <button type="submit" class="form-control btn btn-fill but">Register</button>
                        </form>
                    </div>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </body>
</html>