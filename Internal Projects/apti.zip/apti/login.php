<?php 
    session_start();
    if(isset($_SESSION["type"]))
        header("Location: ".$_SESSION['type']."/home.php");
?>
<?php
require_once 'setup/database/DB_Functions.php';
$db = new DB_Functions();
if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $login = $db->getUserByEmailAndPassword($email, $password);
    if($login) {
        session_start();
        $_SESSION["id"] = $login["id"];
        $_SESSION["type"] = $login["type"];
        $_SESSION["name"] = $login["name"];
        $_SESSION["branch"] = $login["branch"];
        header("Location: ".$_SESSION["type"]."/home.php");
    }
    else
        echo "<script>alert('Login credentials are wrong. Please try again!');</script>";
}
?>
<html>
    <head>
        <meta charset="utf-8" />
        <!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>Login</title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />
        <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>bootstrap/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    </head>
    <body>
        <div class="container hvcenter">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <div class="form-container text-center">
                        <form method="post">   
                            <div class="form-group">
                                <input class="form-control" type="email" placeholder="Email" required id="email" name="email" required />
                            </div>          
                			<div class="form-group">
                                <input class="form-control" type="password" placeholder="Password" required id="pass" name="password" required />
                            </div>
                			<button type="submit" class="form-control btn btn-fill but">Login</button>
                        </form>
                    </div>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </body>
</html>
