-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2017 at 07:15 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aptitude`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `correct` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `correct`) VALUES
(1, 'C'),
(2, 'D'),
(3, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `opt_A` text NOT NULL,
  `opt_B` text NOT NULL,
  `opt_C` text NOT NULL,
  `opt_D` text NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `opt_A`, `opt_B`, `opt_C`, `opt_D`, `answer`, `category`) VALUES
(1, 'which one of the following is a security goal?', 'Flexibility', 'Scalability', 'Integirity', 'Scalability', 'C', 'techCSIT'),
(2, 'what is the time complexity for IDDFS?\r\nwhere b is branching factor & d is the depth', 'b+d', 'b', 'd', 'b*d', 'D', 'techCSIT'),
(3, 'A train running at the speed of 60 km/hr crosses a pole in 9 seconds. What is the length of the train?', '120 metres\r\n', '180 metres', '324 metres', '150 metres', 'D', 'quant'),
(4, 'A train 125 m long passes a man, running at 5 km/hr in the same direction in which the train is going, in 10 seconds. The speed of the train is:', '45 km/hr', '50 km/hr', '54 km/hr', '55 km/hr', 'B', 'quant'),
(5, 'The length of the bridge, which a train 130 metres long and travelling at 45 km/hr can cross in 30 seconds, is:', '200 m', '225 m', '245 m', '250 m', 'C', 'quant'),
(6, 'A train 240 m long passes a pole in 24 seconds. How long will it take to pass a platform 650 m long?', '65 sec', '89 sec', '100 sec', '150 sec', 'B', 'quant'),
(7, 'A train 360 m long is running at a speed of 45 km/hr. In what time will it pass a bridge 140 m long?', '40 sec', '42 sec', '45 sec', '48 sec', 'A', 'quant'),
(23, 'asdf', 'sd', 'asdf', 'sdf', 'sdfg', 'A', 'quant');

-- --------------------------------------------------------

--
-- Table structure for table `statistics`
--

CREATE TABLE `statistics` (
  `id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `test_name` varchar(50) NOT NULL,
  `student_id` int(11) NOT NULL,
  `total_questions` int(11) NOT NULL,
  `max_score` int(11) NOT NULL,
  `total_score` int(11) NOT NULL,
  `verbal_score` int(11) NOT NULL,
  `quant_score` int(11) NOT NULL,
  `tech_score` int(11) NOT NULL,
  `verbal_correct` int(11) NOT NULL,
  `verbal_incorrect` int(11) NOT NULL,
  `quant_correct` int(11) NOT NULL,
  `quant_incorrect` int(11) NOT NULL,
  `tech_correct` int(11) NOT NULL,
  `tech_incorrect` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `statistics`
--

INSERT INTO `statistics` (`id`, `test_id`, `test_name`, `student_id`, `total_questions`, `max_score`, `total_score`, `verbal_score`, `quant_score`, `tech_score`, `verbal_correct`, `verbal_incorrect`, `quant_correct`, `quant_incorrect`, `tech_correct`, `tech_incorrect`, `timestamp`) VALUES
(1, 1, 'Test101', 1, 40, 100, 100, 50, 50, 0, 20, 5, 15, 0, 0, 1, '2017-12-26 13:18:05'),
(2, 1, 'Test101', 1, 40, 100, 102, 51, 51, 0, 20, 10, 20, 0, 0, 0, '2017-12-26 13:18:15'),
(3, 1, 'Test101', 1, 40, 100, 111, 54, 57, 0, 20, 10, 30, 0, 0, 0, '2017-12-26 13:18:15'),
(4, 1, 'Test101', 1, 40, 100, 110, 57, 53, 0, 20, 5, 25, 0, 0, 0, '2017-12-26 13:18:15'),
(5, 1, 'Test101', 1, 40, 100, 40, 10, 30, 0, 20, 7, 15, 0, 0, 0, '2017-12-26 13:18:15'),
(6, 1, 'Test101', 1, 40, 100, 60, 5, 55, 0, 20, 0, 20, 0, 0, 0, '2017-12-26 13:18:15'),
(7, 2, 'Test101', 2, 40, 100, 50, 20, 20, 10, 20, 0, 10, 0, 5, 0, '2017-12-26 13:18:15'),
(8, 1, 'Test 101', 2, 30, 90, 3, 3, 0, 0, 1, 2, 0, 0, 0, 0, '2017-12-29 17:47:51'),
(9, 1, 'Test 101', 3, 30, 90, 15, 0, 12, 3, 0, 0, 4, 1, 1, 1, '2017-12-29 17:53:41');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `duration` int(11) NOT NULL,
  `quant` int(11) NOT NULL,
  `verbal` int(11) NOT NULL,
  `technical` int(11) NOT NULL,
  `branch` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `name`, `duration`, `quant`, `verbal`, `technical`, `branch`) VALUES
(1, 'Test 101', 50, 10, 10, 10, 'techCSIT');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `branch` varchar(32) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `branch`, `type`) VALUES
(1, 'Akhil Pillai', 'ak@ak.com', '545d26918d43a640c4bed801fa7c86a4', 'techCSIT', 'student'),
(2, 'Aaroosh', 'aar@aar.com', '5d9ff9a0923bd93b9bf476160b9bfce4', 'techCSIT', 'student'),
(3, 'alex', 'alex@alex.com', '534b44a19bf18d20b71ecc4eb77c572f', 'techCSIT', 'student'),
(4, 'Saurabh', 'st@st.com', '133057facf49cbe6520b15a4d96ee395', 'techCSIT', 'student'),
(5, 'T', 't@t.com', 'accc9105df5383111407fd5b41255e23', 'techCSIT', 'teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_no` (`id`),
  ADD KEY `question_no_2` (`id`);

--
-- Indexes for table `statistics`
--
ALTER TABLE `statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `statistics`
--
ALTER TABLE `statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
