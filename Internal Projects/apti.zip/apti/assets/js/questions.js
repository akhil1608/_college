function next(){
	var current = $(".question").not(".hidden");
	var next = current.next();
	var button = parseInt(current.attr("id").substring(1));
	if(current.is(".question:first"))
		$("#pre").removeClass("hidden");
	if(next.is(".question:last"))
		$("#next").addClass("hidden");
	current.toggleClass("hidden");
	next.toggleClass("hidden");
	active(button,button+1);
}
function previous(){
	var current = $(".question").not(".hidden");
	var prev = current.prev();
	var button = parseInt(current.attr("id").substring(1));
	if(current.is(".question:last"))
		$("#next").removeClass("hidden");
	if(prev.is(".question:first"))
		$("#pre").addClass("hidden");
	current.toggleClass("hidden");
	prev.toggleClass("hidden");
	active(button,button-1);
}
function navi(id){
	var current = $(".question").not(".hidden");
	var to = $(".question:nth-of-type("+id+")");
	var button = parseInt(current.attr("id").substring(1));
	if(current.index()!=to.index()) {
		if(current.is(".question:first"))
			$("#pre").removeClass("hidden");
		if(current.is(".question:last"))
			$("#next").removeClass("hidden");
		if(to.is(".question:first"))
			$("#pre").addClass("hidden");
		if(to.is(".question:last"))
			$("#next").addClass("hidden");
		current.toggleClass("hidden");
		to.toggleClass("hidden");
		active(button,id);
	}
}
function active(a,b) {
	$("#b"+a).toggleClass("current");
	$("#b"+b).toggleClass("current");
}