$(document).ready(function() {
	window.onblur = function() {
		post();
	}	
});