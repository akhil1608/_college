$(document).ready(function() {
	$("input[type='radio']").change(function() {
		$("#b"+$(this).parent().attr("id").substring(1)).css("background-color","#32CD32");
	});
	$("#review").click(function() {
		var q = $(".question").not(".hidden");
		if(q.children("input[type='radio']").first().prop("checked")) {
			$("#b"+q.attr("id").substring(1)).css("background-color","#FFA07A");
		}
	});
	$("#unselect").click(function() {
		var q = $(".question").not(".hidden")
		var r = q.children("input[type='radio']");
		if(!r.first().prop("checked")) {
			r.prop("checked",false);
			r.first().prop("checked",true);
			$("#b"+q.attr("id").substring(1)).css("background-color","");
		}
	});
});