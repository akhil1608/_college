var counter = $("#counter").val()*60-1;
var timer = setInterval(function() {
	var m = Math.floor(counter / 60);
	var s =counter - m * 60;
	counter--;
	document.getElementById("timer").innerHTML= m+" mins "+s+" secs";
	if(counter==-1) {
		clearInterval(timer);
		post();
	}
},1000);
function post() {
	$("#test-form").submit();
}