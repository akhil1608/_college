<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="student")
    	header("Location: ../student/home.php")
?>
<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$cp = new Components();
	$db = new DB_Functions();
    $failed = $db->getFailedStudentList();
    $pending = $db->getPendingStudents();
    $today = time();
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Home</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

    <?php $cp->sidebart(THEME_URL,0); ?>

	<div class="main-panel">

		<?php $cp->header(NAME,$_SESSION["name"]); ?>

		<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <?php if(empty($failed)){?><div class="content"><h3>No failed students</h3></div><?php } else {?>
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                        <th>Student Name</th>
                                        <th>Test Name</th>
                                        <th>Score</th>
                                    </thead>
                                    <tbody>
                                        <?php $c = 0; foreach($failed as $f) {?>
                                            <tr>
                                                <td><?php echo ++$c; ?></td>
                                                <td><?php echo $f['student_name']; ?></td>
                                                <td><?php echo $f['test_name']; ?></td>
                                                <td><?php echo $f['score']; ?></td>
                                                <td>
                                                    <form action="fail-mail.php" method="post">
                                                        <input type="submit" value="Send Reminder Mail">
                                                        <input type="hidden" name="test_name" value="<?php echo $f['test_name']; ?>">
                                                        <input type="hidden" name="student_id" value="<?php echo $f['student_id']; ?>">
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php }}?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                        	<div class="content table-responsive table-full-width">
                                <?php if(empty($pending)){?><div class="content"><h3>No pending students to left to give test</h3></div><?php } else {?>
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                        <th>Student Name</th>
                                        <th>Test Name</th>
                                        <th>Days Remaining</th>
                                    </thead>
                                    <tbody>
                                        <?php $c = 0; foreach($pending as $p) {?>
                                            <tr>
                                                <td><?php echo ++$c; ?></td>
                                                <td><?php echo $p['student_name']; ?></td>
                                                <td><?php echo $p['test_name']; ?></td>
                                                <?php $diff = strtotime($p['end_date'])-$today; ?>
                                                <td><?php echo ceil($diff/86400); ?></td>
                                            </tr>
                                        <?php }}?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $cp->footer(THEME_URL); ?>

    </div>
</div>
</body>
<?php $cp->js(THEME_URL); ?>
</html>