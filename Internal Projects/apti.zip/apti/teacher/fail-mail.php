<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	$db = new DB_Functions();
	$student = $db->getEmailByID($_POST["student_id"]);
	$from="no-reply@fcritplacements.com";
	$to = $student["email"];
	$subject = "F.C.R.I.T - Aptitude Test Results Notification";
	$name = $student["name"];
	$test = $_POST["test_name"];
	$body ="Dear ".$name.",\n\n\tThank you for completing the aptitude test as part of your placement training. This email serves as a notification that your test result has been rendered. Your test '".$test."' has been evaluated and we regret to inform you that you have failed to get the minimum marks required to clear the passing requirements. For detailed results about the exact scores and weak areas, login into your placement account and check the statistics.\n\n\tAptitude tests are the first round for almost all placement proceedings. This notification serves as an indication of your progress and goes to show that you will require more practice when it comes to aptitude. You can use the following resources for the same:\n\n1. Refer https://www.indiabix.com\n2. R.S. Agarwal\n\nThe placement coordinators are always around to help you for the same. If you have any questions, please do not hesitate to contact us.\n\nP.S. This is a system generated email. Please do not reply.";
	$r = mail($to,$subject,$body,'From: '.$from);
	if($r)
		header("Location: home.php");
	else
		echo "Failed. Reload the page to try again.";
?>