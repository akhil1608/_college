<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="student")
      header("Location: ../student/home.php")
?>
<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$cp = new Components();
	$db = new DB_Functions();
	if(!empty($_POST)) {
		$db = new DB_Functions();
		$add = $db->createTest($_POST);
		if($add) {
			$_SESSION["status"] = "success";
			$_SESSION["message"] = "successful";
		}
		else {
			$_SESSION["status"] = "danger";
			$_SESSION["message"] = "unsuccessful";
		}
		header("Location: createtest.php");
		exit; //the page will load twice if not used. notification won't work then.
	}
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Create Test</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta name="viewport" content="width=device-width" />
	<link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
	<?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

	<?php $cp->sidebart(THEME_URL,1); ?>

	<div class="main-panel">

		<?php $cp->header(NAME,$_SESSION["name"]); ?>

		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<?php if(isset($_SESSION["status"])) { ?>
						<div class="row notification">
							<div class="col-md-12">
								<div class="alert alert-<?php echo $_SESSION['status'];?>">
				                    <span>Test creation <?php echo $_SESSION['message'];?>.<button type="button" aria-hidden="true" onclick="closenotif()" class="pull-right close-but">×</button></span>
				                </div>
				            </div>
				        </div>
				        <?php unset($_SESSION["status"]); unset($_SESSION["message"]); }?>
						<div class="card">
							<div class="content">
								<h3 class="title">Create Test: </h3><br>
						        <form method="post">
						        	<h5 class="title">Basic:</h5>
						            <div class="row">
						            	<div class="col-md-12">
							          		<div class="form-group">
            									<label>Enter Test Name: </label>
            									<input type="text" placeholder="Test Name" name="name" required>
        									</div>
        								</div>
        							</div>
        							<div class="row">
						            	<div class="col-md-12">
							          		<div class="form-group">
            									<label>Duration (mins): </label>
            									<input type="number" min=0 placeholder="30" name="dur" required>
        									</div>
        								</div>
        							</div>
        							<h5 class="title">Number of questions in section:</h5>
        							<div class="row">
						            	<div class="col-md-4">
							          		<div class="form-group">
            									<label>Quants: </label>
            									<input type="number" min=0 placeholder="10" name="quant" required>
            								</div>
            							</div>
						            	<div class="col-md-4">
							          		<div class="form-group">
        										<label>Verbal: </label>
        										<input type="number" min=0 placeholder="10" name="verbal" required>
        									</div>
        								</div>
						            	<div class="col-md-4">
							          		<div class="form-group">
        										<label>Technical: </label>
        										<input type="number" min=0 placeholder="10" name="tech" required>
        									</div>
        								</div>
        							</div>
        							<h5 class="title">Other details:</h5>
        							<div class="row">
        								<div class="col-md-6">
        									<div class="form-group">
        										<label>Start Date: </label>
        										<input type="date" name="start_date" id="start" value="<?php echo date('Y-m-d'); ?>" min="<?php echo date('Y-m-d'); ?>">
        									</div>
        								</div>
        								<div class="col-md-6">
        									<div class="form-group">
        										<label>End Date: </label>
        										<input type="date" name="end_date" id="end" min="" required>
        									</div>
        								</div>
        							</div>
        							<div class="row">
						            	<div class="col-md-12">
							          		<div class="form-group">
									            <label>Branch: </label>
									            <select name="branch">
								                	<option value="techCSIT" selected>CS and IT</option>
									                <option value="techME">Mech</option>
									                <option value="techEL">Elec</option>
									                <option value="techEX">EXTC</option>
									            </select>
									        </div>
									    </div>
									</div>
									<button type="submit" class="btn btn-info btn-fill">Create</button>
						          	<button type="reset" class="btn btn-info btn-fill">Reset</button>           
						        </form>
					        </div>
					    </div>
					</div>
				</div>
			</div>
		</div>

		<?php $cp->footer(THEME_URL); ?>

    </div>
</div>
</body>
<?php $cp->js(THEME_URL); ?>
<script type="text/javascript">
	function closenotif() {
		$(".notification").css("display","none");
	}
	$(document).ready(function(){
		$("#start,#end").change(function() {
			if($("#end").val() <= $("#start").val()) {
				alert("Start date should preceed end date.");
				var sd = new Date($("#start").val());
				sd.setDate(sd.getDate()+1);
				var d = ("0" + sd.getDate()).slice(-2); 
				var m = ("0" + (sd.getMonth()+1)).slice(-2);
				var y = sd.getFullYear();
				$("#end").val(y+"-"+m+"-"+d);
			}
		});
	});
</script>
</html>