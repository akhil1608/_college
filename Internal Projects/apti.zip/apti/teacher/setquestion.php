<?php 
    session_start();
    if(empty($_SESSION["type"]))
        header("Location: ../login.php");
    if($_SESSION["type"]=="student")
    	header("Location: ../student/home.php")
?>
<?php
	require_once '../setup/config.php';
	require_once '../setup/database/DB_Functions.php';
	require_once '../assets/php/components.php';
	$cp = new Components();
	$db = new DB_Functions();
	if(!empty($_POST)) {
		$db = new DB_Functions();
		$add = $db->addQuestion($_POST);
		if($add) {
			$_SESSION["status"] = "success";
			$_SESSION["message"] = "successfully";
		}
		else {
			$_SESSION["status"] = "danger";
			$_SESSION["message"] = "unsuccessfully";
		}
		header("Location: setquestion.php");
		exit; //the page will load twice if not used. notification won't work then.
	}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<!-- <link rel="icon" type="image/png" href="img/favicon.ico"> -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Add Question</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta name="viewport" content="width=device-width" />
	<link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
	<?php $cp->css(THEME_URL); ?>
</head>
<body>

<div class="wrapper">

	<?php $cp->sidebart(THEME_URL,2); ?>

	<div class="main-panel">

		<?php $cp->header(NAME,$_SESSION["name"]); ?>

		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<?php if(isset($_SESSION["status"])) { ?>
						<div class="row notification">
							<div class="col-md-12">
								<div class="alert alert-<?php echo $_SESSION['status'];?>">
				                    <span>Question added <?php echo $_SESSION['message'];?>.<button type="button" aria-hidden="true" onclick="closenotif()" class="pull-right close-but">×</button></span>
				                </div>
				            </div>
				        </div>
				        <?php unset($_SESSION["status"]); unset($_SESSION["message"]); }?>
						<div class="card">
							<div class="content">
						        <form method="post">
						            <div class="row">
						            	<div class="col-md-12">
							          		<div class="form-group">
							          			<label>Enter Question: </label><br>
							          			<textarea  name="question" placeholder="Type Question here..." rows="6" cols="100" id="question" required></textarea>
							          		</div>
							          	</div>
						          	</div>
						          	<div class="row">
						          		<div class="col-md-6">
							          		<div class="form-group">
							          			<label>Option A: </label>
							          			<input type="text" placeholder="Option A" name="opt_A" required>
							          		</div>
							          	</div>
							          	<div class="col-md-6">
							          		<div class="form-group">
							          			<label>Option B: </label>
							          			<input type="text" placeholder="Option B" name="opt_B" required>
							          		</div>
							          	</div>
							        </div>
							        <div class="row">
							          	<div class="col-md-6">
							          		<div class="form-group">
							          			<label>Option C: </label>
							          			<input type="text" placeholder="Option C" name="opt_C" required>
							          		</div>
							          	</div>
							          	<div class="col-md-6">
							          		<div class="form-group">
							          			<label>Option D: </label>
							          			<input type="text" placeholder="Option D" name="opt_D" required>
							          		</div>
							          	</div>
							        </div>
						          	<div class="row">
						          		<div class="col-md-12">
							          		<div class="form-group">
							          			<label>Correct option: </label>
							          			<select name="correct_opt">
									              <option value="A" selected>A</option>
									              <option value="B">B</option>
									              <option value="C">C</option>
									              <option value="D">D</option>
									            </select>
								            </div>
								        </div>
							        </div>
							        <div class="row">
							        	<div class="col-md-12">
							          		<div class="form-group">
							          			<label>Category: </label>
									            <select name="category">
									              <option value="quant" selected>Quantitative</option>
									              <option value="verbal">Verbal</option>
									                <optgroup label="Technical">
									                  <option value="techCSIT">Technical: CS and IT</option>
									                  <option value="techME">Technical: Mech</option>
									                  <option value="techEL">Technical: Elec</option>
									                  <option value="techEX">Technical: EXTC</option>
									                </optgroup>
									            </select>
									        </div>
								        </div>
								    </div>
						         	<button type="submit" class="btn btn-info btn-fill">Add</button>
						          	<button type="reset" class="btn btn-info btn-fill">Reset</button>           
						        </form>
					        </div>
					    </div>
					</div>
				</div>
			</div>
		</div>

		<?php $cp->footer(THEME_URL); ?>

    </div>
</div>
</body>
<?php $cp->js(THEME_URL); ?>
<script type="text/javascript">
	function closenotif() {
		$(".notification").css("display","none");
	}
</script>
</html>
