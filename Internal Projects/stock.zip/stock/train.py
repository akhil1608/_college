import numpy as np, math as m, os, sys

path = "stock_data/"+sys.argv[1]+"/"
rate = float(sys.argv[3])
hidden = 2
inputs = 3
outputs = 1
file = open(path+"parameters.txt","w")
file.write(str(inputs)+"\n")
file.write(str(hidden)+"\n")
file.write(str(outputs)+"\n")
epochs = int(sys.argv[2])
threshold = float(sys.argv[4])
weights1 = np.random.random((inputs,hidden))
weights2 = np.random.random((hidden,outputs))

def activation_function(z):
    return 1/(1+m.exp(-z))

def forward(layer1,weights):
	layer2 = np.dot(layer1,weights)
	for i in range(len(layer2)):
		layer2[i] = activation_function(layer2[i])
	return layer2

def backward(y,t,h):
	global weights2
	for i in range(hidden):
		error = 0.5*(y-t)*(y-t)
		one = y-t
		two = y*(1-y)
		three = h[i]
		correction = rate*one*two*three
		weights2[i] = weights2[i]-correction

def read_csv(file):
	csv_file = open(file,"r")
	c = np.zeros(inputs)
	close = np.zeros(1)
	for line in csv_file:
		l = line.rstrip().split(",")
		l = np.delete(np.delete(np.delete(l,0,0),4,0),4,0)
		close = np.vstack((close,l[3]))
		l =	np.delete(l,3,0)
		c = np.vstack((c,l))
	c = np.delete(np.delete(c,0,0),0,0)
	close = np.delete(np.delete(close,0,0),0,0)
	return c.astype(float),close.astype(float)

def normalize(d,M,m):
	n = d
	n[:] = (d[:]-m)/(M-m)
	return n

def normalize_csv(c):
	n = c
	for i in range(inputs):
		M = max(c[:,i])
		m = min(c[:,i])
		n[:,i] = (c[:,i]-m)/(M-m)
	return n

csv,closing = read_csv(path+os.listdir(path)[0])
file.write(str(max(csv[:,0]))+"\n")
file.write(str(min(csv[:,0]))+"\n")
file.write(str(max(csv[:,1]))+"\n")
file.write(str(min(csv[:,1]))+"\n")
file.write(str(max(csv[:,2]))+"\n")
file.write(str(min(csv[:,2]))+"\n")
file.write(str(float(min(closing)))+"\n")
norm_csv = normalize_csv(csv)
length = len(csv)
pacc = 0.0
flag = 0

for k in range(epochs):
	count = 0.0
	output_layer = np.zeros(outputs)
	h = np.zeros(hidden)

	for i in range(length):
		input_layer = norm_csv[i].astype(float)
		hidden_layer = forward(input_layer,weights1)
		output_layer = np.vstack((output_layer,forward(hidden_layer,weights2)))
		h = np.vstack((h,hidden_layer))

	output_layer = np.delete(output_layer,0,0)
	h = np.delete(h,0,0)
	norm_closing = normalize(closing,max(closing),min(closing))
	norm_closing = norm_closing*(max(output_layer)-min(output_layer))+min(output_layer)

	for i in range(length):
		y = output_layer[i]
		t = norm_closing[i]
		if(abs(y-t)>threshold):
			backward(y,t,h[i])
			count += 1

	acc = 100-count*100/len(norm_csv)
	if (pacc>acc) or acc >= 80:
		break
	pacc = acc

print(acc)
print(k+1)
file.write(str(float(max(output_layer)))+"\n")
file.write(str(float(min(output_layer)))+"\n")
for i in range(inputs):
	for j in range(hidden):
		file.write(str(weights1[i][j])+"\n")
for i in range(hidden):
	for j in range(outputs):
		file.write(str(weights2[i][j])+"\n")
file.close()