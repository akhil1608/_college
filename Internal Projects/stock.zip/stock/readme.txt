Prerequisites:
1. python (>2.7)
2. pip (to install packages)

Startup:
1. Extract the contents of the folder to some destination.
2. Open terminal, navigate to the folder and execute "python app.py" (without quotes).
3. It may show some error due to missing/unknown packages. Install the required packages using pip. (Eg. pip install sqlalchemy)
4. Once the command in step 2 is successfully executed, a link will be shown on the terminal (http://127.0.0.1:6969/). Open the link in browser to begin the application.

In-app:
1. Open http://127.0.0.1:6969/login, to login as an admin. Admin can add company and train the parameters of neural network.
2. Open http://127.0.0.1:6969/ as a normal user, one can closing predict values.

Admin Credentials:
username: akhil
password: akhil

username: aaroosh
password: aaroosh