from flask import Flask, flash, redirect, render_template, request, session, abort
import os
from sqlalchemy.orm import sessionmaker
from tabledef import *
from tabledef2 import *
engine = create_engine('sqlite:///database/admins.db', echo=False)
engine2 = create_engine('sqlite:///database/companies.db', echo=False)
app = Flask(__name__)

def queryObject(e,t):
    Session = sessionmaker(bind=e)
    s = Session()
    return s.query(t)
 
@app.route('/admin/home')
def admin():
    if not session.get('logged_in'):
        return redirect("/login")
    else:
        co = queryObject(engine2,Company).all()
        return render_template("/admin/home.html",company=co)

@app.route('/admin/addCompany',methods=['POST'])
def add():
    company = request.form['company']
    directory = "stock_data/"+company
    os.makedirs(directory)
    csv = request.files['csv']
    csv.save(os.path.join(directory,csv.filename))
    Session = sessionmaker(bind=engine2)
    s = Session()
    s.add(Company(company))
    s.commit()
    return redirect('/admin/home')

@app.route('/admin/train',methods=['POST'])
def train():
    company = request.form['company']
    e = request.form['e']
    c = request.form['c']
    t = request.form['t']
    o = os.popen("python train.py "+company+" "+e+" "+c+" "+t).read()
    flash(o)
    return redirect('/admin/home')

@app.route('/')
def home():
    co = queryObject(engine2,Company).all()
    return render_template("user/predict.html",company=co)

@app.route('/predict',methods=['POST'])
def predict():
    print("entered")
    company = request.form['company']
    o = request.form['o']
    h = request.form['h']
    l = request.form['l']
    c = os.popen("python predict.py "+company+" "+o+" "+h+" "+l).read()
    flash(c)
    return redirect('/')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/logsub', methods=['POST'])
def do_admin_login():
    POST_USERNAME = str(request.form['username'])
    POST_PASSWORD = str(request.form['password'])
    query = queryObject(engine,User).filter(User.username.in_([POST_USERNAME]), User.password.in_([POST_PASSWORD]) )
    result = query.first()
    if result:
        session['logged_in'] = True
        return redirect("/admin/home")
    else:
        flash('Wrong Password!')
        return login()	
 
@app.route("/logout")
def logout():
    session['logged_in'] = False
    return redirect("/login")
 
if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=False,host='0.0.0.0', port=6969)