import numpy as np, sys, math

file = open("stock_data/"+sys.argv[1]+"/parameters.txt")
i = 0
j = 0
k = 0
m = 0
n = 0
for line in file:
	l = line.rstrip()
	if i == 0:
		inputs = int(l)
	elif i == 1:
		hidden = int(l)
	elif i == 2:
		outputs = int(l)
		weights1 = np.zeros((inputs,hidden))
		weights2 = np.zeros((hidden,outputs))
	elif i == 3:
		openmax = float(l)
	elif i == 4:
		openmin = float(l)
	elif i == 5:
		highmax = float(l)
	elif i == 6:
		highmin = float(l)
	elif i == 7:
		lowmax = float(l)
	elif i == 8:
		lowmin = float(l)
	elif i == 9:
		closemin = float(l)
	elif i == 10:
		outmax = float(l)
	elif i == 11:
		outmin= float(l)
	elif i <= inputs*hidden+11:
		weights1[j][k] = float(l)
		j = (j+1)%inputs
		k = (k+1)%hidden
	elif i <= hidden*(outputs+inputs)+11:
		weights2[m][n] = float(l)
		m = (m+1)%hidden
		n = (n+1)%outputs
	i += 1

def forward(layer1,weights):
	layer2 = np.dot(layer1,weights)
	for i in range(len(layer2)):
		layer2[i] = activation_function(layer2[i])
	return layer2

def activation_function(z):
    return 1/(1+math.exp(-z))

def normalize(d,M,m):
	n = (d-m)/(M-m)
	return n

input_layer = np.array([normalize(float(sys.argv[2]),openmax,openmin),normalize(float(sys.argv[3]),highmax,highmin),normalize(float(sys.argv[4]),lowmax,lowmin)])
hidden_layer = forward(input_layer,weights1)
output_layer = forward(hidden_layer,weights2)

print(float(output_layer*(outmax-outmin)+closemin))