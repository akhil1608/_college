$(document).ready(function() {
	$("#e").change(function() {
		$("#paper").empty();
		var e=$("#e").val();
		if(e=="ut")
			$("#paper").load("public/structure/ut.html");
		else if(e=="at")
			$("#paper").load("public/structure/at.php");
		else
			$("#paper").load("public/structure/prelims.php");
	});
});