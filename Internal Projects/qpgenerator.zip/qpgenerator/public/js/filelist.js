$(document).ready(function() {
	$("#tostep2,#backtostep2").click(function() {
		$("#filelist").empty();
		var data="sem="+$("#sem").val()+"&branch="+$("#branch").val()+"&sub="+$("#sub").val();
		$.ajax({
			type: "POST",
			url: "http://localhost/qpgenerator/filelist",
			data: data,
			datType: "json",
			cache: false,
			success: function(r){
				if(r=="null")
					$("#filelist").append("<small>No Existing Question Banks Found.<br /> Click on Create a new Question Bank.</small>");
				else {
					var list = parse(r);
					for (var i = 0 ; i < list.length; i++)
						$("#filelist").append('<form method="post" action="create"><input type="hidden" name="details" value="'+$("#branch").val()+','+$("#sem").val()+','+$("#sub").val()+','+list[i]+'" /> <input type="submit" class="list-group-item" value="'+list[i].substring(0,(list[i].length-4))+'" /></form>');
				}
			}
		});
	});
	function parse(k) {
		var temp="";
		for (var i=2; i< k.length - 2; i++)
		temp+=k[i];
		p=temp.split('","');
		return p;
	}
});