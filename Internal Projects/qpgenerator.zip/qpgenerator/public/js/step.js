$(function(){
	$("#editor").froalaEditor();
});
$(document).ready(function() {
	$("#tostep1").click(function() {
		$("#step2").hide();
		$("#step1").fadeIn("slow");
	});
	$("#tostep2").click(function() {
		if(!$("#sub").val()=="") {
			$("#step1").hide();
			$("#branch,#sem,#sub").removeClass("error");
			$("#step2").fadeIn("slow");
		}
		else {
			if($("#branch").val()==null)
				$("#branch").addClass("error");
			else if($("#sem").val()==null) {
				$("#branch").removeClass("error");
				$("#sem").addClass("error");
			}
			else {
				$("#branch,#sem").removeClass("error");
				$("#sub").addClass("error");
			}
		}
	});
	$("#tostep3").click(function() {
		$("#step2").hide();
		$("#step3").fadeIn("slow");
	});
	$("#backtostep2").click(function() {
		var x=confirm("All changes will be discarded.");
		if(x) {
			$("#co").val("");
			$("#c").val("1");
			$("#nof").val("");
			$("#editor").froalaEditor("html.set", "");
			$("#step3").hide();
			$("#step2").fadeIn("slow");
		}
	});
});