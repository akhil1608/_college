$(document).ready(function() {
	var course=[],ques=[],q="",b,s,co,c,sub;
	$("#add").click(function() {
		b=$("#branch").val();
		s=$("#sem").val();
		sub=$("#sub").val();
		co=$("#co").val();
		c=$("#c").val();
		q=$("#editor").froalaEditor("html.get");
		if(q!=""&&co!=""&&c!=null) {
			$("#editor,#c,#co").removeClass("error");
			ques.push(q);
			course.push("<p class='course'>CO"+c+"</p>");
			$("#editor").froalaEditor("html.set","");
			alert("New question added!");
		}
		else {
			if(c==null) {
				$("#co,#editor").removeClass("error");
				$("#c").addClass("error");
			}
			else if(co=="") {
				$("#editor,#c").removeClass("error");
				$("#co").addClass("error");
			}
			else {
				$("#c,#co").removeClass("error");
				$("#editor").addClass("error");
			}
		}
	});
	$("#viewq").dialog({
	    autoOpen: false,
	    width : 900,
	    height : 500,
	    modal : true,
	    title: "Question Bank"
	});
	$("#view").click(function() {
		vdisp();
		$("#viewq").dialog("open");
	});
	$("#viewq").on("click", "button", function() {
		ques.splice($(this).val(), 1);
		course.splice($(this).val(), 1);
		vdisp();
	});
	$("#s").click(function() {
		var contents="";
		var n=$("#nof").val();
		for (var i = 0; i < ques.length; i++)
				contents+=ques[i]+"\r\n"+course[i]+"\r\n";
		//alert(contents);
		if(contents!=""&&n!="") {
			$("#nof").removeClass("error");
			$.ajax({
				type: "POST",
				url: "http://localhost/qpgenerator/save",
				data: {save:contents,branch:b,sem:s,sub:sub,name:n},
				datType: "json",
				cache: false,
				success: function(r) {
					alert("Question Bank Saved!");
					$("#save").html('<form method="post" action="create"><input type="submit" class="button" value="Create Question Paper" /><input type="hidden" name="details" value="'+b+','+s+','+sub+','+n+'.txt" /></form>');
				}
			});
		}
		else {
			if(n=="")
				$("#nof").addClass("error");
			else {
				$("#nof").removeClass("error");
				alert("Add atleast one question to the Question Bank.");
			}
		}
	});
	$("#backtostep2").click(function(){
		ques=[];
		course=[];
	});
	function vdisp() {
		var vq=$("#viewq");
		vq.empty();
		for(var i=0; i<ques.length;i++) {
			vq.append('<div class="row">');
			vq.append('<div class="col-md-1">'+(i+1)+'</div>');
			vq.append('<div class="col-md-9">'+ques[i]+'</div>');
			vq.append('<div class="col-md-1">('+course[i].substring(18,21)+')</div>');
			vq.append('<div class="col-md-1"><button type="button" value="'+i+'">X</button></div></div>');
		}
	}
});