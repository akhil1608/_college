$(document).ready(function() {
	var c="";
	$("#branch,#sem").change(function() {
		$("#sub").empty();
		var b = $("#branch").val();
		if(b!=c) {
			if(b=="First Year")
				$("#sem").html("<option value='' selected disabled>Select Semester</option><option>1</option><option>2</option>");
			else {
				$("#sem").html("<option value='' selected disabled>Select Semester</option>");
				for (var i=3;i<=8;i++)
					$("#sem").append("<option>"+i+"</option>");
			}
		}
		c=b;
		var s = $("#sem").val();
		var data="branch="+b+"&sem="+s;
		if(!(b==""||s=="")) {
			$.ajax({
				type: "POST",
				url: "http://localhost/qpgenerator/sublist",
				data: data,
				datType: "json",
				cache: false,
				success: function(r) {
					var arr = parse(r);
					for (var i = 0 ; i < arr.length; i++) {
						$("#sub").append("<option>"+arr[i]+"</option>");
					}
				}
			});
		}
	});
	function parse(k) {
		var temp="";
		for (var i=2; i< k.length - 2; i++)
		temp+=k[i];
		p=temp.split('","');
		return p;
	}
});