$(document).ready(function() {
	$("#pdf").click(function() {
		var doc=new jsPDF("p","mm","a4");
		var name=$("#name");
	    if(name.val()!="") {
	    	name.removeClass("error");
			doc.addHTML($("#qpaper"),function(a){doc.save(name.val()+".pdf");});
		}
		else 
			name.addClass("error");
	});
})