$(document).ready(function() {
	$("#sub").click(function() {
		var arr=new Array();
		$("input[type=number]").each(function(){
			arr.push($(this).val());
		});
		var uniq = arr.map((arr) => {
		  return {count: 1, arr: arr}
		}).reduce((a, b) => {
		  a[b.arr] = (a[b.arr] || 0) + b.count
		  return a
		}, {});
		var dup = Object.keys(uniq).filter((a) => uniq[a] > 1);
		if(dup!=""&&arr!=[]) {
			alert("Question Number(s) "+dup+" is/are repeated.");
			return false;
		}
	});
});