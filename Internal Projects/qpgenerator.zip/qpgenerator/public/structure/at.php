<script>
	var marks=[[10,10],[8,6,6],[5,5,5,5],[4,4,4,4,4]];
	$(".sub").change(function() {
		$("#atq").empty();
		var n=$(this).val().substring(0,1)
		for (var i = 0; i < n ; i++)
			$("#atq").append((i+1)+') <input type="number" min="1" max="'+$("#total").val()+'" name="'+(i+1)+" "+marks[n-2][i]+'" required /><br /><br />');
	});
</script>
<?php
	echo '<label>Assignment Test Number:</label> <select name="num" required><option>1</option><option>2</option></select><br /><br />
	Select the number of Questions (2-5): 
	<select class="sub" required>
		<option selected disabled value="">Select</option>
		<option>2 (10 marks each)</option>
		<option>3 (8,6,6)</option>
		<option>4 (5 marks each)</option>
		<option>5 (4 marks each)</option>
	</select>
	<div id="atq"></div>';
?>