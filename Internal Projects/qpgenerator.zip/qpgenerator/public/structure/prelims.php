<script>
	var marks=[[10,10],[8,6,6],[5,5,5,5]];
	$(".sub").change(function() {
		var c=$(this).index(".sub")+1;
		$("#utq"+c).empty();
		var n=$(this).val().substring(0,1)
		for (var i = 0; i < n ; i++)
			$("#utq"+c).append(c+') '+String.fromCharCode(97+i)+') <input type="number" min="1" max="'+$("#total").val()+'" name="'+c+String.fromCharCode(97+i)+marks[n-2][i]+'" required /><br /><br />');
	});
</script>
<?php
	for($i=1;$i<=6;$i++)
	echo 'Question '.$i.':<br />
	Select the number of sub-questions (2-4): 
	<select class="sub" required>
		<option selected disabled value="">Select</option>
		<option>2 (10 marks each)</option>
		<option>3 (8,6,6)</option>
		<option>4 (5 marks each)</option>
	</select>
	<div id="utq'.$i.'"></div>';
?>