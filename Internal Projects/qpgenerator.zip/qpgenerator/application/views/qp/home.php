<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="<?php echo base_url().CSS_URL; ?>style.css">
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
		<?php include("editor_css.php"); ?>
	</head>
	<body>
		<div class="container-fluid">
			<div class="header">
					<p align="center" style="font-size:30px;font-family:sans-serif ; color:white; ">
						<img src="<?php echo base_url().IMG_URL; ?>fcritlogo.png" style="width:100px; height:100px; background:none !important;border: none !important;"/>
						FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY
					</p>
				</div>
			</div>
		</div>
		<div id="cont" class="container text-center">
			<div class="box">
				<!-- Selecting Branch, Semester and Subject. subject.js and step.js involved -->
				<div class="row">
					<div class="form-group" id="step1">
						<label>Branch: </label>
						<select id="branch" class="form-control-static">
							<option value="" selected disabled>Select Branch</option>
							<option>First Year</option>
							<option>IT</option>
							<option>Computer</option>
							<option>Mechanical</option>
							<option>EXTC</option>
							<option>Electrical</option>
						</select>
						<br /><br /><label>Semester: </label>
						<select id="sem" class="form-control-static"></select>
						<br /><br /><label>Subject: </label>
						<select id="sub" class="form-control-static"></select>
						<br /><br /><button id="tostep2" class="button">Continue</button>
					</div>
				</div>
				<!-- Selecting an existing file or to create a new question bank. step.js and filelist.js involved -->
				<div class="row">
					<div id="step2">
						<h4>You can either create a new Question Bank or use an exisiting one.</h4>
						<div id="filelist" class="list-group"></div><br />
						<button id="tostep1" class="button">Go Back</button>
						<button id="tostep3" class="button">Create a new Question Bank</button>
					</div>
				</div>
				<!-- Preparing the Question Bank. COs, Editor and name of QB. addq.js and step.js involved -->
				<div class="row">
					<div class="form-group" id="step3">
						<label><b>Course Objective Number</b></label>
						<select id="c" class="form-control-static">
							<option value="" selected disabled>Select CO No.</option>
							<?php 
								for($i=1;$i<=6;$i++) 
									echo '<option>'.$i.'</option>';
							?>
						</select><br />
						<label><b>Course Objective</b></label><br />
						<textarea id="co" rows="2" cols="50" class="form-control-static" placeholder=""></textarea><br />
						<label><b>Name of the Question Bank:</b></label>
						<input type="text" id="nof" placeholder="(Eg. Subject-UT-FH-2017)" class="form-control-static" /><br /><br />
						<div id="editor"></div><br />
						<button id="backtostep2" class="button">Go Back</button>
						<button id="add" class="button">Add question</button>
						<button id="view" class="button">View Added Questions</button>
						<button id="s" class="button">Save Question Bank</button>
						<div id="save"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- Pop up to display the questions that are added so far. addq.js involved -->
		<div id="viewq"></div>
		<!--Script files. Do not change the order.-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<?php include("editor_js.php"); ?>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>step.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>filelist.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>addq.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>subject.js"></script>
	</body>
</html>