<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/froala_editor.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/froala_style.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/code_view.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/draggable.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/colors.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/image_manager.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/image.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/line_breaker.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/table.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/char_counter.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/fullscreen.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/quick_insert.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/help.css">
<link rel="stylesheet" href="<?php echo base_url().JS_URL; ?>froala/css/plugins/special_characters.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.css">