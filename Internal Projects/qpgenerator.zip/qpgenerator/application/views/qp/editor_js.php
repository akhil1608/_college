<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/mode/xml/xml.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/froala_editor.min.js" ></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/align.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/char_counter.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/code_beautifier.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/code_view.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/colors.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/draggable.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/entities.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/font_size.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/font_family.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/fullscreen.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/image.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/image_manager.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/line_breaker.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/inline_style.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/lists.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/paragraph_format.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/paragraph_style.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/quick_insert.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/quote.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/table.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/help.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().JS_URL; ?>froala/plugins/special_characters.min.js"></script>