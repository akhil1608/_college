<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="<?php echo base_url().CSS_URL; ?>style.css">
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
		<link href="https://fonts.googleapis.com/css?family=Lato|Montserrat" rel="stylesheet" type="text/css">
	</head>
	<body>
		<div class="container" id="qpaper">
			<div class="row text-center">
				<h2>Fr. C. Rodrigues Institute of Technology, Vashi</h2>
				<h3><?php echo $exam." (".$half.")"; ?></h3>
				<h3><?php echo $branch; ?></h3>
				<div class="row">
					<div class="col-md-4 pull-left">Subject: <?php echo $sub; ?></div>
					<div class="col-md-4">Date: <?php echo $date; ?></div>
					<div class="col-md-4 pull-right">Semester: <?php echo $sem; ?></div>
				</div>
				<div class="row">
					<div class="col-md-6">Marks: <?php echo $marks; ?></div>
					<div class="col-md-6 pull-right">Duration: <?php echo $dur; ?></div>
				</div>
				<h4 class="pull-left"><hr/><?php echo $rules; ?><hr/></h4>
			</div>
			<?php
				foreach ($questions as $key => $value) {
					echo '<div class="row"><div class="col-md-1">'.substr($key,0,2).'</div><div class="col-md-9">'.$value.'</div>
					<div class="col-md-1">('.$cono[$key].')</div><div class="col-md-1">['.substr($key,2).']</div></div>';
				}
			?>
		</div>
		<div class="container text-center">
			<label>Enter Name of the Question Paper:</label>  <input id="name" type="text" />
			<button type="button" id="pdf">Save Pdf</button><br /><br />
		</div>
		<!--Script files. Do not change the order.-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>jspdf.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>pdf.js"></script>
	</body>
</html>