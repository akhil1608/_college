<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="<?php echo base_url().CSS_URL; ?>style.css">
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
		<link href="https://fonts.googleapis.com/css?family=Lato|Montserrat" rel="stylesheet" type="text/css">
	</head>
	<body id="top">
		<div class="container-fluid">
			<div class="header">
					<p align="center" style="font-size:30px;font-family:sans-serif ; color:white; ">
						<img src="<?php echo base_url().IMG_URL; ?>fcritlogo.png" style="width:100px; height:100px; background:none !important;border: none !important;"/>
						FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY
					</p>
				</div>
			</div>
		</div>
		<input id="total" type="hidden" value="<?php echo $total; ?>" />
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="qb">
						<?php 
							$c=0;
							foreach($qb as $key => $value) {
								if($c%2)
									echo '<div class="row"><div class="col-md-1"></div><div class="col-md-11">'.$value.'</div></div>'; 
								else
									echo '<div class="row"><div class="col-md-1">'.($c/2+1).'</div><div class="col-md-11"'.$value.'</div></div>';
								$c++;
							}
						?>
					</div>
				</div>
				<!-- Setting the paper. ques.js, examstruct.js repeat.js and structure/ involved -->
				<div class="col-md-6">
					<div class="qb">
						<form action="paper" method="post" target="_blank">
							<input type="hidden" name="path" value="<?php echo $path; ?>" />
							<label>Select Exam Type: </label>
							<select id="e" name="exam-type" required>
								<option selected disabled value="">Exam</option>
								<option value="at">Assignment Test</option>
								<option value="ut">Unit Test</option>
								<option value="prel">Prelims</option>
							</select>
							<div id="paper"></div>
							<div>
								<select name="half" required><option value="FH">First Half</option><option value="SH">Second Half</option></select>
								<input type="number" name="yyyy" min="2017" max="2022" required/><br />
								<br /><input type="date" name="date" /><em> Optional</em><br /><br />
							</div>
							<input type="submit" name="s" id="sub">
						</form>
					</div>
				</div>
			</div>
		</div>
		<!--Script files. Do not change the order.-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="<?php echo base_url().JS_URL; ?>examstruct.js"></script>
		<script src="<?php echo base_url().JS_URL; ?>repeat.js"></script>
	</body>
</html>