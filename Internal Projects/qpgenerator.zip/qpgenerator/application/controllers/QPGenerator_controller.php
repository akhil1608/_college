<?php
class QPGenerator_controller extends CI_Controller {
	// Pages Visible to the user.
	// Home Page. Create a Question Bank.
	public function index() {
		$this->load->view("qp/home");
	}
	//Use Question Bank to form Question Paper.
	public function create() {
		if(empty($_POST))
			$this->load->view("errors/html/error_403");
		else {
			$p=explode(",", $_POST["details"]);
			$path="banks/".$p[0]."/".$p[1]."/".$p[2]."/".$p[3];
			$qb=file($path);
			$data=array("qb"=>$qb,"path"=>$path,"total"=>(count($qb)/2));
			$this->load->view("qp/create",$data);
		}
	}
	// Display the generated Question Paper to either print or save.
	public function paper() {
		if(empty($_POST))
			$this->load->view("errors/html/error_403");
		else {
			$p=$_POST["path"];
			$qp=file($p);
			$i=0;
			foreach ($_POST as $key => $value) {
				if($key!="exam-type"&&$key!="s"&&$key!="path"&&$key!="num"&&$key!="date"&&$key!="yyyy"&&$key!="half") {
					$qno[$key]=$qp[2*($value-1)];
					$k=""+substr($qp[2*$value-1],20,21);
					$co[$key]="CO".$k;
				}
			}
			$et=$_POST["exam-type"];
			$num="";
			if(!empty($_POST["num"]))
				$num=$_POST["num"];
			$h=$_POST["half"]."-".$_POST["yyyy"];
			$p=explode("/", $p);
			$branch=array("IT"=>"Information Technology","Mechanical"=>"Mechanical Engineering","Electrical"=>"Electrical Engineering","EXTC"=>"Electronics and Telecommunication","Computer"=>"Computer Engineering");
			$exam=array("ut"=>"Internal Assesment - ".$num,"prel"=>"Prelims","at"=>"Assignment Test - ".$num);
			$marks=array("ut"=>20,"prel"=>80,"at"=>20);
			$duration=array("ut"=>"1 Hour","prel"=>"3 Hour","at"=>"1 Hour");
			$rules=array("ut"=>"Attempt any five questions from Question 1. Attempt any one from Question 2 and Question 3.","prel"=>"Question 1 is compulsory. Attempt any three from the remaining questions","at"=>"Attempt all the questions.");
			$b="Department of ".$branch[$p[1]];
			$e=$exam[$et];
			$sem=$p[2];
			$sub=$p[3];
			$m=$marks[$et];
			$d=$duration[$et];
			$dat="&nbsp&nbsp&nbsp-&nbsp&nbsp&nbsp-";
			$r=$rules[$et]." Figures on the right indicate full marks";
			if(!empty($_POST["date"]))
				$dat=$_POST["date"];
			$data=array("questions"=>$qno, "cono"=>$co,"exam"=>$e, "half"=>$h,"branch"=>$b,"sem"=>$sem,"sub"=>$sub,"marks"=>$m,"dur"=>$d,"date"=>$dat,"rules"=>$r);
			$this->load->view("qp/paper",$data);
		}
	}
	// Hidden activities performed from here on.
	// List of subjects generated via ajax call from subject.js
	public function sublist() {
		if(empty($_POST))
			$this->load->view("errors/html/error_403");
		else {
			$this->load->model("QPGenerator_model");
			$c = array("semester" => $_POST["sem"]);
			$res = $this->QPGenerator_model->select($_POST["branch"],"subject",$c);
			if(!empty($res)) {
				for($i=0;$i<count($res);$i++)
					$r[$i]=$res[$i]["subject"];
				echo json_encode($r);
			}
		}
	}
	// List of files generated via ajax call from filelist.js
	public function filelist() {
		if(empty($_POST))
			$this->load->view("errors/html/error_403");
		else {
			$arr=get_filenames("banks/".$_POST["branch"]."/".$_POST["sem"]."/".$_POST["sub"]."/");
			if(!empty($arr))
				echo json_encode($arr);
			else
				echo "null";
		}
	}
	// Save the question bank to the server via ajax call from addq.js
	public function save() {
		if(empty($_POST))
			$this->load->view("errors/html/error_403");
		else 
			write_file("banks/".$_POST["branch"]."/".$_POST["sem"]."/".$_POST["sub"]."/".$_POST["name"].".txt", $_POST["save"]);
	}
}
?>